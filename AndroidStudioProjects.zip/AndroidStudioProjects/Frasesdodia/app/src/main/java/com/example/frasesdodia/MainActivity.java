package com.example.frasesdodia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void gerarNovaFrase (View view){
        String [] frases={
                "Se você quer ser bem-sucedido precisa de dedicação total, buscar seu último limite e dar o melhor de si mesmo",
                "Não crie limites para si mesmo. Você deve ir tão longe quanto sua mente permitir. O que você mais quer pode ser conquistado",
                "Nenhum obstáculo será grande se a sua vontade de vencer for maior",
                "Dificuldades preparam pessoas comuns para destinos extraordinários",
                "Pessoas vencedoras não são aquelas que não falham, são aquelas que não desistem"
        };

        int numero= new Random().nextInt(frases.length);

        TextView texto=(TextView) findViewById(R.id.textViewResultado);

        texto.setText(frases[numero]);
    }
}